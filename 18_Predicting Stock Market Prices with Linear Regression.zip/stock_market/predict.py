import pandas as pd
from datetime import datetime
from sklearn.metrics import mean_absolute_error
from sklearn.linear_model import LinearRegression
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("sphist.csv")
df["Date"] = pd.to_datetime(df["Date"], infer_datetime_format=True)

df = df.sort_values(by="Date", ascending=True)
#print(df.head())

df["5d_avg"] = df["Close"].rolling(5).mean().shift(1)
df["30d_avg"] = df["Close"].rolling(30).mean().shift(1)
df["365d_avg"] = df["Close"].rolling(365).mean().shift(1)

df["5d_std"] = df["Close"].rolling(5).std().shift(1)
df["30d_std"] = df["Close"].rolling(30).std().shift(1)
df["365d_std"] = df["Close"].rolling(365).std().shift(1)

df["5d_coef"] = df["5d_std"] / df["5d_avg"]
df["30d_coef"] = df["30d_std"] / df["30d_avg"]
df["365d_coef"] = df["365d_std"] / df["365d_avg"]

#for validation reasons
#print(df[df["Date"] == datetime(year = 1951, month = 1, day = 3)])

df_clean = df.dropna(axis=0)

train = df_clean[df_clean["Date"] < datetime(year=2013, month=1, day=1)]
test = df_clean[df_clean["Date"] >= datetime(year=2013, month=1, day=1)]

#print(train.shape[0], test.shape[0])

reg = LinearRegression()
target = "Close"
features = train.columns[7:]
reg.fit(train[features], train[target])
predictions = reg.predict(test[features])
mae = mean_absolute_error(test[target], predictions)
print("Mean Absolute Error over all {} features is {:.2F}.".format(len(features), mae))

'''    
for feature in features:
    reg = LinearRegression()
    reg.fit(train[feature].reshape(-1,1), train[target])
    predictions = reg.predict(test[feature].reshape(-1,1))
    mae = mean_absolute_error(test[target], predictions)
    print("Mean Absolute Error for feature {} is {:.2F}.".format(feature, mae))'''

df["5d_vol_avg"] = df["Volume"].rolling(5).mean().shift(1)
df["365d_vol_avg"] = df["Volume"].rolling(365).mean().shift(1)
df["avg_vol_ratio"] = df["5d_vol_avg"] / df["365d_vol_avg"]

df["5d_vol_std"] = df["Volume"].rolling(5).mean().shift(1)
df["365d_vol_std"] = df["Volume"].rolling(365).mean().shift(1)
df["std_vol_ratio"] = df["5d_vol_std"] / df["365d_vol_std"]

df["act_min_ratio"] = df["Close"].shift(1) / df["Close"].rolling(365).min().shift(1)
df["act_max_ratio"] = df["Close"].shift(1) / df["Close"].rolling(365).max().shift(1)
df["weekday"] = df["Date"].dt.dayofweek
df["day"] = df["Date"].dt.day
df["month"] = df["Date"].dt.month
df["year"] = df["Date"].dt.year

#print(df.head())

df_clean = df.dropna(axis=0)

train = df_clean[df_clean["Date"] < datetime(year=2013, month=1, day=1)]
test = df_clean[df_clean["Date"] >= datetime(year=2013, month=1, day=1)]

reg = LinearRegression()
target = "Close"
features = train.columns[7:]
reg.fit(train[features], train[target])
predictions = reg.predict(test[features])
mae = mean_absolute_error(test[target], predictions)
print("Mean Absolute Error over all {} features is {:.2F}.".format(len(features),mae))

'''
for feature in features:
    reg = LinearRegression()
    reg.fit(train[feature].reshape(-1,1), train[target])
    predictions = reg.predict(test[feature].reshape(-1,1))
    mae = mean_absolute_error(test[target], predictions)
    print("Mean Absolute Error for feature {} is {:.2F}.".format(feature, mae))'''
    
# one day ahead predictions
rolling_train = df_clean[:15486]
rolling_test = df_clean[15486:]
predictions = []
for i in range(739):
    rolling_train = df_clean[i:15486+i]
    one_day = rolling_train.iloc[-1:]
    reg = LinearRegression()
    reg.fit(rolling_train[features], rolling_train[target])
    prediction = reg.predict(one_day[features])
    predictions.append(prediction)

mae = mean_absolute_error(rolling_test[target], predictions)
print("MAE for one day prediction is {}.".format(mae))

plt.plot(predictions, color="r")
plt.plot(rolling_test[target], color="b")
plt.show()